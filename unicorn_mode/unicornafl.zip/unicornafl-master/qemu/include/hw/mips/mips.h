#ifndef HW_MIPS_H
#define HW_MIPS_H

void mips_machine_init(struct uc_struct *uc);
void mips_cpu_register_types(void *opaque);

#endif
