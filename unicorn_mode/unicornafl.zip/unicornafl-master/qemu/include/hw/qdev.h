#ifndef QDEV_H
#define QDEV_H

#include "hw/hw.h"
#include "hw/qdev-core.h"

#endif
