module Unicorn
  VERSION = "1.0.1"
end
